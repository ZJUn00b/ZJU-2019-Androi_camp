package com.percy.minidouyin.view.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.percy.minidouyin.R;

public class CameraActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

}
